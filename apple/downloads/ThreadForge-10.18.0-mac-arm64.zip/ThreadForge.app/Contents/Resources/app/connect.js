'use strict';
const THEMES=['sapphire','emerald','light','dark','cvd','system'];
function savedTheme(){try{const t=localStorage.getItem('tf-theme');return THEMES.includes(t)?t:'sapphire';}catch{return 'sapphire';}}
function applyTheme(mode){
  if(mode==='system')document.documentElement.removeAttribute('data-theme');
  else document.documentElement.dataset.theme=mode;
}
applyTheme(savedTheme());
const themeSelect=document.getElementById('desktop-theme-select');
if(themeSelect){
  themeSelect.value=savedTheme();
  themeSelect.addEventListener('change',()=>{
    const next=THEMES.includes(themeSelect.value)?themeSelect.value:'sapphire';
    try{localStorage.setItem('tf-theme',next);}catch{}
    applyTheme(next);
  });
}
const fsBtn=document.getElementById('fullscreen-toggle');
if(fsBtn){
  const canFs=!!(document.documentElement.requestFullscreen&&document.fullscreenEnabled!==false);
  if(!canFs)fsBtn.hidden=true;
  else{
    const syncFs=()=>{
      const on=!!document.fullscreenElement;
      fsBtn.textContent=on?'⛝ Exit full screen':'⛶ Full screen';
      fsBtn.setAttribute('aria-label',on?'Exit full screen':'Enter full screen');
      fsBtn.setAttribute('aria-pressed',String(on));
    };
    fsBtn.addEventListener('click',()=>{
      const req=document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();
      if(req&&req.catch)req.catch(()=>{});
    });
    document.addEventListener('fullscreenchange',syncFs);
    syncFs();
  }
}
const status=document.getElementById('status');
function busy(value){document.querySelectorAll('button:not([data-fullscreen-toggle])').forEach(button=>{button.disabled=value;});}
document.getElementById('open-local').addEventListener('click',async()=>{
  busy(true);status.textContent='Starting your local business suite…';
  try{const result=await window.threadforge.openLocalSuite();if(!result.ok)status.textContent=result.error;}
  catch{status.textContent='The local suite could not start. Your existing records were preserved.';}
  finally{busy(false);}
});
document.getElementById('open-care').addEventListener('click',async()=>{
  busy(true);status.textContent='Opening PC care in its own window…';
  try{const result=await window.threadforge.openCare();status.textContent=result.ok?'PC care is open in a separate window.':result.error;}
  catch{status.textContent='PC care could not start.';}
  finally{busy(false);}
});
const field=document.getElementById('origin'),reopen=document.getElementById('reopen'),anyway=document.getElementById('open-anyway');
async function connect(value,confirmed){
  busy(true);anyway.hidden=true;status.textContent='Checking that this is a ThreadForge workspace…';
  try{
    const result=await window.threadforge.connect(value,{confirmed});
    if(!result.ok){status.textContent=result.error;anyway.hidden=!result.unverified;anyway.dataset.origin=value;}
  }
  catch{status.textContent='Connection failed. Check your gateway address.';}
  finally{busy(false);}
}
document.getElementById('connect-form').addEventListener('submit',event=>{event.preventDefault();void connect(field.value,false);});
anyway.addEventListener('click',()=>{void connect(anyway.dataset.origin,true);});
reopen.addEventListener('click',()=>{void connect(reopen.dataset.origin,false);});
field.addEventListener('input',()=>{anyway.hidden=true;});
function applyDesktopBranding(b){
  if(!b)return;
  const rawCredit=b.credit||'';
  const credit=rawCredit.includes('2026')?rawCredit:'Powered by © 2026 Threadforge Inc.';
  const tagline=b.tagline||'Business & Intelligence Workspace';
  const sub=document.getElementById('desktop-brand-sub');
  if(sub)sub.textContent=tagline+' · '+credit;
  if(b.app_name){
    const title=document.getElementById('desktop-brand-title');
    if(title&&title.childNodes[0])title.childNodes[0].textContent=b.app_name;
    document.title=b.app_name+' · '+tagline+' — '+credit;
  }
  if(b.tagline){
    const tag=document.getElementById('desktop-brand-tagline');
    if(tag)tag.textContent=b.tagline;
  }
  if(b.logo_base64){
    const mark=document.querySelector('.mark');
    if(mark){
      const img=document.createElement('img');
      img.className='mark';img.alt=b.app_name||'';
      img.src='data:'+(b.logo_mime||'image/png')+';base64,'+b.logo_base64;
      img.style.maxHeight='42px';img.style.objectFit='contain';
      mark.replaceWith(img);
    }
  }
  if(b.primary_color){
    const style=document.createElement('style');
    style.textContent=':root{--brand:'+b.primary_color+';--focus:'+b.primary_color+';}';
    document.head.append(style);
  }
}

// ThreadForge no longer opens a remote address by itself at launch; it offers it here.
window.threadforge.lastWorkspace().then(async saved=>{
  if(!saved?.url)return;
  reopen.dataset.origin=saved.url;reopen.textContent='Reopen '+new URL(saved.url).host+' →';reopen.hidden=false;
  if(!field.value)field.value=saved.url;
  try{
    const res=await fetch(saved.url+'/api/suite/branding/shell');
    if(res.ok)applyDesktopBranding(await res.json());
  }catch{}
}).catch(()=>{});
