'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('threadforge',Object.freeze({
  connect:(url,options)=>ipcRenderer.invoke('threadforge-connect',url,{confirmed:options?.confirmed===true}),
  lastWorkspace:()=>ipcRenderer.invoke('threadforge-last-workspace'),
  openLocalSuite:()=>ipcRenderer.invoke('threadforge-open-local-suite'),
  openCare:()=>ipcRenderer.invoke('threadforge-open-care'),
  // Microsoft Store edition only; main.cjs refuses this for any other build or caller.
  purchaseTier:productId=>ipcRenderer.invoke('threadforge-purchase-tier',productId)
}));
