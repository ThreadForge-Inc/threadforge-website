'use strict';
const {app,BrowserWindow,ipcMain,shell,Menu,nativeTheme}=require('electron');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const http=require('node:http'),net=require('node:net'),{spawn}=require('node:child_process');
const {pathToFileURL}=require('node:url');
const CONNECT=pathToFileURL(path.join(__dirname,'connect.html')).href;
const LOCAL_SMOKE=app.commandLine.hasSwitch('local-smoke-test');
const SMOKE=LOCAL_SMOKE||app.commandLine.hasSwitch('smoke-test');
const SINGLE_INSTANCE=SMOKE||app.requestSingleInstanceLock();
if(!SINGLE_INSTANCE)app.quit();
const DEFAULT_USER_DATA=app.getPath('userData');
let smokeDirectory=null;
if(LOCAL_SMOKE){
  const requested=app.commandLine.getSwitchValue('smoke-profile');
  if(requested){
    if(!path.isAbsolute(requested)||!/^threadforge-desktop-smoke-[0-9a-f]{32}$/.test(path.basename(requested))||
       fs.realpathSync.native(path.dirname(requested))!==fs.realpathSync.native(os.tmpdir())||
       !fs.lstatSync(requested).isDirectory()||fs.lstatSync(requested).isSymbolicLink()||fs.readdirSync(requested).length){
      throw new Error('Smoke verification requires its own empty temporary profile.');
    }
    smokeDirectory=requested;
  }else smokeDirectory=fs.mkdtempSync(path.join(os.tmpdir(),'threadforge-desktop-smoke-'));
  app.setPath('userData',smokeDirectory);
}
let window,gateway=null,localGateway=null,startingLocal=null,quitting=false;
function origin(value){
  const u=new URL(value),local=['localhost','127.0.0.1','[::1]'].includes(u.hostname);
  if((u.protocol!=='https:'&&!(local&&u.protocol==='http:'))||u.username||u.password||u.search||u.hash||!['','/'].includes(u.pathname))throw new Error('Enter an HTTPS workspace origin or development loopback origin.');
  return u.origin;
}
function external(value){
  try{const u=new URL(value);return u.protocol==='https:'&&u.hostname==='github.com'&&/^\/[^/]+\/[^/]+\/pull\/\d+$/.test(u.pathname)&&!u.username&&!u.password;}catch{return false;}
}
function trustedConnection(event){
  return !!window&&event.sender===window.webContents&&event.senderFrame===window.webContents.mainFrame&&event.senderFrame.url===CONNECT;
}
// Store purchases are triggered from the running suite page (People & access), not the connect
// screen -- same sender/frame checks as trustedConnection, against the local gateway origin instead.
function trustedSuiteConnection(event){
  if(!window||!gateway||event.sender!==window.webContents||event.senderFrame!==window.webContents.mainFrame)return false;
  try{return new URL(event.senderFrame.url).origin===gateway;}catch{return false;}
}
// Must exactly match threadforge.licence.STORE_PRODUCT_TIERS; the owner creates one Partner Center
// add-on per tier with a real Store ID recorded in windows-store-tiers.json (left blank by default).
const TIER_PRODUCT_IDS=['tier_essentials','tier_professional','tier_industrial','tier_industrial_park'];
function windowsStoreTiersPath(){
  return path.join(process.resourcesPath||__dirname,'windows-store-tiers.json');
}
function windowsStoreScriptPath(){
  return path.join(process.resourcesPath||__dirname,'windows-store-purchase.ps1');
}
function runWindowsStoreScript(args){
  return new Promise((resolve,reject)=>{
    const script=windowsStoreScriptPath();
    if(!fs.existsSync(script)){reject(new Error('The Microsoft Store purchase helper is missing from this installation.'));return;}
    const psHome=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
    const child=spawn(psHome,['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,...args],{windowsHide:true});
    let stdout='',stderr='',done=false;
    const finish=(error,value)=>{if(done)return;done=true;error?reject(error):resolve(value);};
    child.stdout.on('data',chunk=>{stdout+=chunk;if(stdout.length>65536)child.kill();});
    child.stderr.on('data',chunk=>{stderr+=chunk;if(stderr.length>65536)child.kill();});
    child.once('error',()=>finish(new Error('The Microsoft Store purchase helper could not start.')));
    const timer=setTimeout(()=>{child.kill();finish(new Error('The Microsoft Store purchase helper timed out.'));},90000);
    child.once('exit',()=>{
      clearTimeout(timer);
      const line=stdout.trim().split('\n').pop();
      try{finish(null,JSON.parse(line));}
      catch{finish(new Error('The Microsoft Store purchase helper did not return a result.'));}
    });
  });
}
// Reuses the session cookie the suite WebContents already holds (set in authenticateLocal) rather
// than signing in again, mirroring how requestLocal/authenticateLocal already talk to the local
// backend elsewhere in this file.
async function reportStoreEntitlement(productId){
  if(!gateway)throw new Error('The local workspace is not open.');
  const cookies=await window.webContents.session.cookies.get({name:'threadforge_session',url:gateway});
  if(!cookies.length)throw new Error('Not signed in to the local workspace.');
  const cookieHeader='threadforge_session='+cookies[0].value;
  const fresh=await requestLocal(gateway,'/api/session',{headers:{Cookie:cookieHeader}});
  if(fresh.status!==200||!fresh.json?.csrf)throw new Error('The local service could not confirm the session.');
  const response=await requestLocal(gateway,'/api/suite/store/entitlement',{method:'POST',
    headers:{Origin:gateway,'X-CSRF-Token':fresh.json.csrf,Cookie:cookieHeader},
    body:{platform:'microsoft_store',product_id:productId}});
  if(response.status!==200)throw new Error(response.json?.error||'The purchase could not be recorded in this workspace.');
  return response.json;
}
async function purchaseTier(productId){
  if(process.platform!=='win32'||!process.windowsStore)throw new Error('Store purchases are only available in the Microsoft Store edition.');
  if(!TIER_PRODUCT_IDS.includes(productId))throw new Error('Unknown tier product.');
  let tiers;
  try{tiers=JSON.parse(fs.readFileSync(windowsStoreTiersPath(),'utf8'));}
  catch{throw new Error('The Microsoft Store tier configuration is missing from this installation.');}
  const storeId=tiers[productId];
  if(typeof storeId!=='string'||!storeId.trim())throw new Error('This tier has not been set up for purchase in the Microsoft Store yet.');
  const purchase=await runWindowsStoreScript(['-Action','Purchase','-StoreId',storeId]);
  if(!purchase||purchase.status!=='Succeeded')throw new Error(purchase&&purchase.message?purchase.message:'The purchase was not completed.');
  return reportStoreEntitlement(productId);
}
function statePath(){return path.join(app.getPath('userData'),'gateway.json');}
function runtimePath(){return path.join(app.getPath('userData'),'suite-runtime');}
function save(url){fs.writeFileSync(statePath(),JSON.stringify({url}),{mode:0o600});}
function backendPath(){
  // A packaged application only executes its own bundled resource.
  const override=!app.isPackaged&&app.commandLine.getSwitchValue('local-backend');
  return override?path.resolve(override):path.join(process.resourcesPath||__dirname,'threadforge.exe');
}
function careLaunch(executable,environment=process.env,licenceFile=path.join(runtimePath(),'threadforge.licence')){
  // cmd's start command gives the console tool its own window for prompts.
  // Paths containing cmd metacharacters are refused instead of quoted.
  if(!path.isAbsolute(executable)||/["%!^&|<>\r\n]/.test(executable))throw new Error('PC care cannot start from this installation path.');
  // Only the licence's location and the Store edition pass through, so PC care can tell whether repairs are included.
  const env={...Object.fromEntries(Object.entries(environment).filter(([key])=>!key.toUpperCase().startsWith('THREADFORGE_'))),
    THREADFORGE_LICENCE_FILE:licenceFile,...(process.windowsStore?{THREADFORGE_EDITION:'microsoft_store'}:{})};
  return {command:path.join(environment.SystemRoot||'C:\\Windows','System32','cmd.exe'),args:['/d','/c','start','"ThreadForge PC care"','"'+executable+'"','care','--hold'],
    options:{env,stdio:'ignore',windowsHide:true,windowsVerbatimArguments:true}};
}
async function openCare(){
  if(process.platform!=='win32')throw new Error('PC care is included in the Windows application.');
  const executable=backendPath();
  if(!fs.existsSync(executable))throw new Error('The bundled PC care tool is unavailable.');
  const launch=careLaunch(executable);
  await new Promise((resolve,reject)=>{const child=spawn(launch.command,launch.args,launch.options);child.once('error',reject);child.once('spawn',()=>{child.unref();resolve();});});
}
function childEnvironment(config,url,database){
  const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>!key.toUpperCase().startsWith('THREADFORGE_')));
  // A Microsoft Store purchase counts as ThreadForge Essentials without a licence file.
  const edition=process.windowsStore?{THREADFORGE_EDITION:'microsoft_store'}:{};
  return {...env,THREADFORGE_CONFIG:config,THREADFORGE_ORIGIN:url,THREADFORGE_MODE:'development',THREADFORGE_DATABASE:database,PYTHONUNBUFFERED:'1',...edition};
}
function containedFile(directory,value){
  if(typeof value!=='string'||!path.isAbsolute(value))throw new Error('Invalid local runtime configuration.');
  // Python expands Windows short names and directory junctions. Node's native
  // resolver also expands 8.3 names; its JavaScript resolver can preserve them.
  const root=fs.realpathSync.native(directory);
  let exists=true;
  try{fs.lstatSync(value);}
  catch(error){
    if(error.code!=='ENOENT')throw error;
    exists=false;
  }
  // An existing dangling link must fail realpath rather than become a new file.
  const target=exists?fs.realpathSync.native(value):path.join(fs.realpathSync.native(path.dirname(value)),path.basename(value));
  const relative=path.relative(root,target);
  if(!relative||relative==='..'||relative.startsWith('..'+path.sep)||path.isAbsolute(relative))throw new Error('Local runtime files must remain in the application data directory.');
  return target;
}
function freePort(){
  return new Promise((resolve,reject)=>{
    const reservation=net.createServer();reservation.once('error',reject);
    reservation.listen(0,'127.0.0.1',()=>{const port=reservation.address().port;reservation.close(error=>error?reject(error):resolve(port));});
  });
}
function runInit(executable,args,env){
  return new Promise((resolve,reject)=>{
    const child=spawn(executable,args,{env,stdio:'ignore',windowsHide:true});
    const timer=setTimeout(()=>{child.kill();reject(new Error('Local configuration creation timed out.'));},45000);
    child.once('error',()=>{clearTimeout(timer);reject(new Error('The bundled local service could not start.'));});
    child.once('exit',code=>{clearTimeout(timer);code===0?resolve():reject(new Error('Local configuration creation failed. Existing files were preserved.'));});
  });
}
function requestLocal(url,route,{method='GET',headers={},body}={}){
  const target=new URL(route,url);
  if(target.origin!==url||target.protocol!=='http:'||target.hostname!=='127.0.0.1')throw new Error('Local requests require the owned loopback gateway.');
  return new Promise((resolve,reject)=>{
    const data=body===undefined?undefined:JSON.stringify(body);
    const request=http.request(target,{method,headers:{...headers,...(data?{'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)}:{})}},response=>{
      let value='';response.setEncoding('utf8');
      response.on('data',chunk=>{value+=chunk;if(value.length>2*1024*1024)request.destroy(new Error('Local response was too large.'));});
      response.on('end',()=>{
        let json=null;try{json=JSON.parse(value);}catch{}
        resolve({status:response.statusCode,headers:response.headers,json,text:value});
      });
      response.once('error',reject);
    });
    request.setTimeout(3000,()=>request.destroy(new Error('Local request timed out.')));
    request.once('error',reject);request.end(data);
  });
}
function cookie(response){
  const value=(response.headers['set-cookie']||[]).find(item=>item.startsWith('threadforge_session='));
  if(!value)throw new Error('Local sign-in did not create a private session.');
  return value.split(';',1)[0];
}
function portClosed(url){
  return new Promise(resolve=>{
    const socket=net.connect({host:'127.0.0.1',port:Number(new URL(url).port)});
    let settled=false;
    const finish=closed=>{if(settled)return;settled=true;socket.destroy();resolve(closed);};
    socket.once('connect',()=>finish(false));socket.once('error',error=>finish(error.code==='ECONNREFUSED'));
    socket.setTimeout(500,()=>finish(false));
  });
}
async function stopLocalGateway(){
  const owned=localGateway;
  if(!owned)return true;
  if(!owned.child.pid||owned.spawnError){localGateway=null;return true;}
  if(owned.child.exitCode===null&&owned.child.signalCode===null){
    await new Promise(resolve=>{
      let settled=false;
      const finish=()=>{if(settled)return;settled=true;clearTimeout(force);clearTimeout(limit);owned.child.removeListener('close',finish);owned.child.removeListener('exit',finish);owned.child.removeListener('error',finish);resolve();};
      const kill=signal=>{try{owned.child.kill(signal);}catch{finish();}};
      const force=setTimeout(()=>kill('SIGKILL'),5000),limit=setTimeout(finish,8000);
      owned.child.once('close',finish);owned.child.once('exit',finish);owned.child.once('error',finish);
      if(process.platform==='win32'){
        // PyInstaller's one-file bootloader also owns a child; terminate only our process tree.
        const killer=spawn(path.join(process.env.SystemRoot||'C:\\Windows','System32','taskkill.exe'),['/PID',String(owned.child.pid),'/T','/F'],{stdio:'ignore',windowsHide:true});
        killer.once('error',()=>kill());killer.once('exit',code=>{if(code!==0)kill();});
      }else kill();
    });
  }
  const deadline=Date.now()+5000;
  while(Date.now()<deadline){
    if((owned.child.exitCode!==null||owned.child.signalCode!==null)&&await portClosed(owned.url)){
      if(localGateway===owned)localGateway=null;return true;
    }
    await new Promise(resolve=>setTimeout(resolve,100));
  }
  return false;
}
async function startLocalGateway(){
  if(localGateway&&localGateway.child.exitCode===null&&localGateway.child.signalCode===null)return localGateway;
  const executable=backendPath();
  if(!fs.existsSync(executable))throw new Error('The bundled local service is unavailable. Install the complete Windows application.');
  const directory=runtimePath(),configPath=path.join(directory,'runtime.json');
  const port=await freePort(),url=`http://127.0.0.1:${port}`;
  const database=path.join(directory,'threadforge.sqlite');
  const env=childEnvironment(configPath,url,database);
  if(!fs.existsSync(directory)){
    await runInit(executable,['init','--directory',directory,'--origin',url,'--repo','ThreadForge-Inc/SO','--execution','local'],env);
  }
  // An incomplete or customized runtime is never overwritten by the launcher.
  const config=JSON.parse(fs.readFileSync(configPath,'utf8'));
  if(!config||typeof config!=='object'||Array.isArray(config)||Object.entries(config).some(([key,value])=>!key.startsWith('THREADFORGE_')||typeof value!=='string'))throw new Error('The existing local runtime configuration is invalid.');
  const tokenPath=containedFile(directory,config.THREADFORGE_ACCESS_TOKEN_FILE);
  env.THREADFORGE_DATABASE=containedFile(directory,config.THREADFORGE_DATABASE);
  const child=spawn(executable,['serve','--host','127.0.0.1','--port',String(port)],{env,stdio:'ignore',windowsHide:true});
  const owned={child,url,configPath,tokenPath,spawnError:false};localGateway=owned;
  child.once('error',()=>{owned.spawnError=true;});
  const deadline=Date.now()+45000;
  while(Date.now()<deadline){
    if(owned.spawnError||child.exitCode!==null||child.signalCode!==null)break;
    try{
      const health=await requestLocal(url,'/api/health');
      if(health.status===200&&health.json?.status==='ok'&&health.json?.version===require('./package.json').version&&child.exitCode===null&&child.signalCode===null&&!owned.spawnError)return owned;
    }catch{}
    await new Promise(resolve=>setTimeout(resolve,250));
  }
  await stopLocalGateway();throw new Error('The local service did not become ready. Close conflicting applications and try again.');
}
async function authenticateLocal(owned){
  if(owned!==localGateway||owned.child.exitCode!==null||owned.child.signalCode!==null)throw new Error('The owned local service is no longer running.');
  const token=fs.readFileSync(owned.tokenPath,'utf8').replace(/[\r\n]+$/,'');
  if(token.length<32||!/^\S+$/.test(token))throw new Error('The existing local workspace token is invalid.');
  const initial=await requestLocal(owned.url,'/api/session');
  if(initial.status!==200||!initial.json?.csrf)throw new Error('The local service could not establish a session.');
  const signedIn=await requestLocal(owned.url,'/api/login',{method:'POST',headers:{Origin:owned.url,'X-CSRF-Token':initial.json.csrf,Cookie:cookie(initial)},body:{token}});
  if(signedIn.status!==200||signedIn.json?.authenticated!==true)throw new Error('Local workspace authentication failed.');
  const sessionCookie=cookie(signedIn);
  // Only a short-lived HttpOnly session reaches Chromium; the owner token stays in main.
  await window.webContents.session.cookies.set({url:owned.url,name:'threadforge_session',value:sessionCookie.slice('threadforge_session='.length),httpOnly:true,secure:false,sameSite:'strict',path:'/',expirationDate:Date.now()/1000+43200});
  return {cookie:sessionCookie,csrf:signedIn.json.csrf};
}
async function openLocalSuite(){
  if(startingLocal)return startingLocal;
  startingLocal=(async()=>{
    const owned=await startLocalGateway();
    const session=await authenticateLocal(owned);gateway=owned.url;
    await window.loadURL(owned.url+'/suite');return {owned,session};
  })();
  try{return await startingLocal;}finally{startingLocal=null;}
}
// A saved or typed address is shown only after it answers as a ThreadForge server.
// Session fetch carries the window's cookies, so a signed-in access proxy still passes.
async function verifyWorkspace(target){
  let timer;
  try{
    const response=await Promise.race([
      window.webContents.session.fetch(target+'/api/health',{redirect:'error',headers:{Accept:'application/json'}}),
      new Promise((_resolve,reject)=>{timer=setTimeout(()=>reject(new Error('Timed out.')),8000);})
    ]);
    if(!response.ok)return false;
    const text=await response.text();
    if(text.length>4096)return false;
    const health=JSON.parse(text);
    return !!health&&health.status==='ok'&&(health.service==='threadforge'||(typeof health.version==='string'&&/^\d+\.\d+\.\d+$/.test(health.version)));
  }catch{return false;}
  finally{clearTimeout(timer);}
}
class NotWorkspace extends Error{}
async function connect(value,{confirmed=false}={}){
  const target=origin(value);
  if(!confirmed&&!await verifyWorkspace(target))throw new NotWorkspace(target);
  // Cookies are shared across ports, including sessions left by a prior launch.
  // A workspace change requires fresh sign-in without disturbing access-proxy cookies.
  const cookies=window.webContents.session.cookies;
  for(const cookie of await cookies.get({name:'threadforge_session'})){
    const host=cookie.domain.replace(/^\./,'');
    const address=new URL(`${cookie.secure?'https':'http'}://${host.includes(':')&&!host.startsWith('[')?'['+host+']':host}`);
    address.pathname=cookie.path||'/';
    await cookies.remove(address.href,'threadforge_session');
  }
  if((await cookies.get({name:'threadforge_session'})).length)throw new Error('The previous workspace session could not be cleared.');
  gateway=target;
  try{await window.loadURL(gateway);save(gateway);}
  catch{gateway=null;await window.loadURL(CONNECT);throw new Error('Connection failed.');}
}
function navigation(event,target){
  let allowed=target===CONNECT;
  try{allowed=allowed||!!(gateway&&new URL(target).origin===gateway);}catch{}
  if(!allowed){event.preventDefault();if(external(target))void shell.openExternal(target);}
}
async function rendererReport(){
  const prefs=window.webContents.getLastWebPreferences();
  const dom=await window.webContents.executeJavaScript("({form:!!document.getElementById('connect-form'),node:typeof require,bridge:typeof window.threadforge?.connect,localBridge:typeof window.threadforge?.openLocalSuite})");
  return {native_window_created:!window.isDestroyed(),context_isolation:prefs.contextIsolation,node_integration:prefs.nodeIntegration,sandbox_enabled:prefs.sandbox,
    connection_screen_loaded:window.webContents.getURL()===CONNECT&&dom.form,renderer_node_unavailable:dom.node==='undefined',connection_bridge_available:dom.bridge==='function',local_bridge_available:dom.localBridge==='function'};
}
async function finishSmoke(report){
  report.local_gateway_stopped=await stopLocalGateway();
  report.passed=report.native_window_created&&report.context_isolation&&!report.node_integration&&report.sandbox_enabled&&report.renderer_node_unavailable&&report.connection_screen_loaded&&report.connection_bridge_available&&report.local_bridge_available&&(!LOCAL_SMOKE||(report.authenticated_suite&&report.inventory_roundtrip&&report.renderer_suite_loaded&&report.local_gateway_stopped&&report.runtime_config_preserved));
  report.default_user_data_path=DEFAULT_USER_DATA;
  // Chromium still holds profile files here. The verifier owns post-exit cleanup.
  report.temporary_user_data_path=smokeDirectory;
  report.temporary_profile_cleanup_pending=!!smokeDirectory;
  const target=app.commandLine.getSwitchValue('smoke-report');
  if(target)fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report));app.exit(report.passed?0:1);
}
async function runSmoke(){
  const report=await rendererReport();report.live_gateway_tested=false;report.model_connection_tested=false;
  if(LOCAL_SMOKE){
    try{
      const {owned,session}=await openLocalSuite();report.local_gateway_started=true;
      const before=fs.readFileSync(owned.configPath,'utf8');
      const headers={Cookie:session.cookie,Origin:owned.url,'X-CSRF-Token':session.csrf};
      const dashboard=await requestLocal(owned.url,'/api/suite',{headers});
      report.authenticated_suite=dashboard.status===200&&dashboard.json?.version===require('./package.json').version;
      const created=await requestLocal(owned.url,'/api/suite/items',{method:'POST',headers,body:{sku:'DESKTOP-SMOKE',name:'Installer verification product',stock:3,unit_cents:150,reorder_level:1}});
      if(created.status!==201)throw new Error('Inventory smoke failed.');
      // Restart against the same configuration to verify stored inventory survives launch.
      if(!await stopLocalGateway())throw new Error('Local service cleanup failed.');
      const restarted=await openLocalSuite();
      const restored=await requestLocal(restarted.owned.url,'/api/suite',{headers:{Cookie:restarted.session.cookie}});
      report.inventory_roundtrip=restored.status===200&&restored.json.items.some(item=>item.sku==='DESKTOP-SMOKE'&&item.stock===3)&&restored.json.metrics.inventory_value_cents==='450';
      report.runtime_config_preserved=fs.readFileSync(restarted.owned.configPath,'utf8')===before;
      const deadline=Date.now()+15000;let rendered=false;
      while(Date.now()<deadline&&!rendered){
        rendered=await window.webContents.executeJavaScript("!!document.getElementById('workspace')&&!document.getElementById('workspace').hidden&&document.getElementById('items').textContent.includes('Installer verification product')");
        if(!rendered)await new Promise(resolve=>setTimeout(resolve,150));
      }
      const assets=await Promise.all(['/suite.css','/suite.js'].map(route=>requestLocal(restarted.owned.url,route)));
      report.renderer_suite_loaded=rendered&&assets.every(response=>response.status===200&&response.text.length>0);
      report.suite_loaded=report.renderer_suite_loaded;report.local_connection_active=gateway===restarted.owned.url;
      report.live_gateway_tested=true;
    }catch{
      // No child output, credentials, response bodies or runtime values enter the report.
      report.local_smoke_error='Bundled local suite verification failed.';
    }
  }
  await finishSmoke(report);
}
async function create(){
  window=new BrowserWindow({width:1280,height:900,minWidth:700,minHeight:560,show:!SMOKE,
    title:'ThreadForge · Business & Intelligence Workspace — Powered by © 2026 Threadforge Inc.',icon:path.join(__dirname,'icon.png'),backgroundColor:nativeTheme?.shouldUseDarkColors?'#061627':'#f3f4ee',webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true}});
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    ...(process.platform==='darwin'?[{role:'appMenu'}]:[]),
    {label:'Workspace',submenu:[{label:'Change workspace…',click:()=>{gateway=null;void window.loadURL(CONNECT);}},{role:'reload'},{role:'quit'}]},
    {role:'editMenu'},{label:'View',submenu:[{label:'Toggle Full Screen',role:'togglefullscreen',accelerator:'F11'}]},
    ...(process.platform==='win32'?[{label:'Tools',submenu:[{label:'PC care — diagnose and repair this PC…',click:()=>{void openCare().catch(()=>{});}}]}]:[])
  ]));
  window.webContents.on('will-navigate',navigation);window.webContents.on('will-redirect',navigation);
  window.webContents.setWindowOpenHandler(({url})=>{if(external(url))void shell.openExternal(url);return {action:'deny'};});
  window.webContents.session.on('will-download',event=>event.preventDefault());
  // Workspaces need no device or browser permissions; Electron grants them unless denied.
  window.webContents.session.setPermissionRequestHandler((_contents,permission,callback)=>callback(permission==='fullscreen'));
  window.webContents.session.setPermissionCheckHandler((_contents,permission)=>permission==='fullscreen');
  await window.loadURL(CONNECT);
  if(SMOKE){await runSmoke();return;}
}
function savedWorkspace(){
  try{const previous=JSON.parse(fs.readFileSync(statePath(),'utf8'));return origin(previous.url);}catch{return null;}
}
ipcMain.handle('threadforge-connect',async(event,value,options)=>{
  if(!trustedConnection(event))throw new Error('Connection changes are only available on the local connection screen.');
  try{await connect(value,{confirmed:options?.confirmed===true});return {ok:true};}
  catch(error){
    if(error instanceof NotWorkspace)return {ok:false,unverified:true,error:`${new URL(error.message).host} did not answer as a ThreadForge workspace, so it was not opened. Check the address. If your workspace sits behind a sign-in gateway, choose Open anyway.`};
    return {ok:false,error:'The workspace could not be opened. Check its HTTPS origin and server status.'};
  }
});
ipcMain.handle('threadforge-last-workspace',async event=>{
  if(!trustedConnection(event))throw new Error('Saved workspaces are only available on the local connection screen.');
  return {url:savedWorkspace()};
});
ipcMain.handle('threadforge-open-local-suite',async event=>{
  if(!trustedConnection(event))throw new Error('Local launch is only available on the local connection screen.');
  try{await openLocalSuite();return {ok:true};}catch{gateway=null;await window.loadURL(CONNECT);return {ok:false,error:'The local suite could not start. Reinstall the complete application if its bundled service is missing. Your existing data and configuration were preserved.'};}
});
ipcMain.handle('threadforge-open-care',async event=>{
  if(!trustedConnection(event))throw new Error('PC care is only available on the local connection screen.');
  try{await openCare();return {ok:true};}catch{return {ok:false,error:'PC care could not start. It is included in the complete Windows application.'};}
});
ipcMain.handle('threadforge-purchase-tier',async(event,productId)=>{
  if(!trustedSuiteConnection(event))throw new Error('Store purchases are only available from the open workspace.');
  try{return {ok:true,status:await purchaseTier(productId)};}
  catch(error){return {ok:false,error:error instanceof Error?error.message:'The purchase could not be completed.'};}
});
if(SINGLE_INSTANCE)app.whenReady().then(create).catch(async()=>{
  await stopLocalGateway();
  if(SMOKE){const report={passed:false,error:'Desktop startup verification failed.',temporary_user_data_path:smokeDirectory,temporary_profile_cleanup_pending:!!smokeDirectory};const target=app.commandLine.getSwitchValue('smoke-report');if(target)fs.writeFileSync(target,JSON.stringify(report,null,2));app.exit(1);}else app.quit();
});
app.on('before-quit',event=>{
  if(quitting)return;quitting=true;
  if(localGateway||startingLocal){event.preventDefault();void (async()=>{try{await startingLocal;}catch{}await stopLocalGateway();app.quit();})();}
});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)void create();});
app.on('second-instance',()=>{if(window&&!window.isDestroyed()){if(window.isMinimized())window.restore();window.focus();}});
module.exports={origin,verifyWorkspace,savedWorkspace,external,careLaunch,childEnvironment,containedFile,requestLocal,freePort,startLocalGateway,stopLocalGateway,authenticateLocal,trustedConnection,trustedSuiteConnection,TIER_PRODUCT_IDS,purchaseTier};
