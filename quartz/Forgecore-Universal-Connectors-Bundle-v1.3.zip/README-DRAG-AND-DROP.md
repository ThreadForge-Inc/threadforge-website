﻿# Forgecore 5-Size Universal Connectors, Extensions & Plugins Bundle (v1.3.2)
**Powered by © 2026 Threadforge Inc.**

Drag, edit, or 1-click install Forgecore Conversational Intelligence (`forgecore-spark-1`, `forgecore-thor-1`, `forgecore-ronin-1`, `forgecore-genesis-1`, `forgecore-titan-1`) across every major AI console & IDE:

| Folder | Platform | Where to Drag / Install |
|---|---|---|
| `01-claude-desktop-and-cli` | **Claude Desktop & Claude Code CLI** | Merge `claude_desktop_config.json` into `%APPDATA%\Claude\` (or run `10-runtime-and-master-installer\INSTALL-ALL-CONNECTORS.ps1`) |
| `02-codex-cli` | **OpenAI Codex CLI** | Drag `config.toml` into `%USERPROFILE%\.codex\config.toml` |
| `03-cursor-ide` | **Cursor IDE** | Drag `mcp.json` into `.cursor/mcp.json` & paste `cursor-models-override.json` into Settings -> Models |
| `04-vscode-extension-and-plugins` | **VS Studio Code / Continue / Cline** | Copy `forgecore-5size-vscode-ext` into `%USERPROFILE%\.vscode\extensions\`, or drag `mcp.json` into `.vscode/` |
| `05-qwen-deepseek-kimi` | **Qwen / DeepSeek / Kimi / OpenCode** | Drag `qwen-settings.json` into `%USERPROFILE%\.qwen\settings.json` or source `.env.forgecore` |
| `06-nvidia-nim-workbench` | **NVIDIA NIM & AI Workbench / LiteLLM** | Import `nvidia-nim-litellm-router.yaml` into LiteLLM / NeMo / AI Workbench |
| `07-microsoft-azure-ai-foundry` | **Microsoft Azure AI Foundry / M365 Copilot / Semantic Kernel** | Import `azure-ai-foundry-connection.json` or `m365-copilot-plugin-manifest.json` |
| `08-google-ai-studio-gemini-antigravity` | **Google AI Studio / Gemini CLI / Antigravity** | Merge `gemini-cli-settings.json` into `%USERPROFILE%\.gemini\settings.json` or paste `google-ai-studio-function-declaration.json` |
| `09-universal-openapi-plugin` | **Any OpenAPI 3.1 Platform (Vertex, Copilot Studio, n8n, Dify, Open WebUI)** | Import `forgecore-openapi-3.1.yaml` |
| `10-runtime-and-master-installer` | **1-Click Windows / Mac / Linux Runtime** | Right-click `INSTALL-ALL-CONNECTORS.ps1` -> Run with PowerShell |
