﻿const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');

function activate(context) {
  const status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
  status.text = '$(sparkle) Forgecore 5-Size';
  status.tooltip = 'Ask Forgecore Spark / Thor / Ronin / Genesis / Titan';
  status.command = 'forgecore.askModel';
  status.show();
  context.subscriptions.push(status);

  const askCmd = vscode.commands.registerCommand('forgecore.askModel', async () => {
    const cfg = vscode.workspace.getConfiguration('forgecore');
    const baseUrl = (cfg.get('baseUrl') || 'http://127.0.0.1:4173/v1').replace(/\/+$/, '');
    const picked = await vscode.window.showQuickPick(
      [
        'forgecore-spark-1',
        'forgecore-thor-1',
        'forgecore-ronin-1',
        'forgecore-genesis-1',
        'forgecore-titan-1',
      ],
      { placeHolder: 'Select Forgecore Model Size (1-5)' }
    );
    if (!picked) return;
    const prompt = await vscode.window.showInputBox({
      prompt: `Ask ${picked}`,
      placeHolder: 'Describe code task, review, or architecture question...',
    });
    if (!prompt) return;

    const channel = vscode.window.createOutputChannel('Forgecore 5-Size');
    channel.show(true);
    channel.appendLine(`\n[${picked}] > ${prompt}\n`);
    try {
      const res = await fetch(`${baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer tfq-sovereign-local' },
        body: JSON.stringify({ model: picked, messages: [{ role: 'user', content: prompt }] }),
      });
      const json = await res.json();
      channel.appendLine(json?.choices?.[0]?.message?.content || JSON.stringify(json, null, 2));
    } catch (err) {
      channel.appendLine(`Error reaching ${baseUrl}: ${err.message}`);
    }
  });

  const mcpCmd = vscode.commands.registerCommand('forgecore.writeWorkspaceMcp', async () => {
    const folder = vscode.workspace.workspaceFolders?.[0];
    if (!folder) {
      vscode.window.showWarningMessage('Open a workspace folder first.');
      return;
    }
    const vscodeDir = path.join(folder.uri.fsPath, '.vscode');
    fs.mkdirSync(vscodeDir, { recursive: true });
    const mcpPath = path.join(vscodeDir, 'mcp.json');
    const scriptPath = path.join(os.homedir(), '.threadforge', 'forgecore-gateway', 'forgecore-mcp-stdio.mjs');
    const content = {
      servers: {
        'forgecore-5size': {
          type: 'stdio',
          command: 'node',
          args: [scriptPath],
        },
      },
    };
    fs.writeFileSync(mcpPath, JSON.stringify(content, null, 2), 'utf8');
    vscode.window.showInformationMessage(`Created ${mcpPath}`);
  });

  context.subscriptions.push(askCmd, mcpCmd);
}

function deactivate() {}
module.exports = { activate, deactivate };
